class SelectionSortClass {
    static class SelectionSort {
        public static void main(String[] args) {
            int[] array = {1, 2, 3, 4, 50, 666, 13}; // заполнение массива
            for (int step = 0; step < array.length; step++) { // метод соротировки массива - выборочный
                int index = min(array, step);
                int temp = array[step];
                array[step] = array[index];
                array[index] = temp;
            }
            Output(array); // вывод
        }

        private static int min(int[] array, int start) {
            int minIndex = start;
            int minValue = array[start];
            for (int i = start + 1; i < array.length; i++) {
                if (array[i] < minValue) {
                    minValue = array[i];
                    minIndex = i;
                }
            }
            return minIndex;
        }

        private static void Output(int[] array) { // метод для вывода данных отсортированного массива
            for (int i : array) {
                System.out.println(" " + i); //Вывод данных
            }


        }
    }
}
// время потраченное на сортировку выбором - 1,774