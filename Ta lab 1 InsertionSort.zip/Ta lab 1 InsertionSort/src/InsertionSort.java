public class InsertionSort {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 50, 666, 13}; // заполнение массива
        for (int i = 1; i < array.length; i++) { // вид сортировки - вставка
            int current = array[i];
            int j = i;
            while (j > 0 && array[j - 1] > current) {
                array[j] = array[j - 1];
                j--;
            }
            array[j] = current;
        }
        Output(array); // вывод
    }

    private static void Output(int[] array) { // метод вывода отсортированного массива
        for (int step = 0; step < array.length; step++) {
            System.out.println(" " + array[step]);
        }
    }
}
//Вермя потраченое на сортировку вставкой - 3
